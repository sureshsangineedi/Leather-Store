
import products from "../data/products"
import ProductCard from "../components/ProductCard"
import Slider from "../components/Slider"

function Home({addToCart}){

return(
<div>

<Slider/>

<h2 style={{textAlign:"center"}}>Our Products</h2>

<div className="product-grid">

{products.map(item=>(
<ProductCard key={item.id} product={item} addToCart={addToCart}/>
))}

</div>

</div>
)
}

export default Home
